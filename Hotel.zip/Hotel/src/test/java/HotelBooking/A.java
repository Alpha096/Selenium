package HotelBooking;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class A {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
    driver = new FirefoxDriver();
    baseUrl = "http://change-this-to-the-site-you-are-testing/";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testA() throws Exception {
    driver.get("file:///D:/hotelBooking/login.html");
    try {
      assertEquals("Hotel Booking Application", driver.findElement(By.xpath("//*[@id='mainCnt']/div/div[1]/h1")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.cssSelector("input.btn")).click();
    try {
      assertTrue(driver.findElement(By.xpath("//*[@id='userErrMsg']")).getText().matches("^[\\s\\S]* Please enter userName\\.$"));
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.name("userName")).clear();
    driver.findElement(By.name("userName")).sendKeys("safasdf");
    driver.findElement(By.cssSelector("input.btn")).click();
    driver.findElement(By.name("userPwd")).clear();
    driver.findElement(By.name("userPwd")).sendKeys("sdfsdf");
    try {
      assertTrue(driver.findElement(By.xpath("//*[@id='pwdErrMsg']")).getText().matches("^[\\s\\S]* Please enter password\\.$"));
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.cssSelector("input.btn")).click();
    assertEquals("Invalid login! Please try again!", closeAlertAndGetItsText());
    driver.findElement(By.name("userName")).clear();
    driver.findElement(By.name("userName")).sendKeys("capgemini");
    driver.findElement(By.cssSelector("input.btn")).click();
    assertEquals("Invalid login! Please try again!", closeAlertAndGetItsText());
    driver.findElement(By.name("userPwd")).clear();
    driver.findElement(By.name("userPwd")).sendKeys("capg1234");
    driver.findElement(By.cssSelector("input.btn")).click();
    driver.findElement(By.id("btnPayment")).click();
    assertEquals("Please fill the First Name", closeAlertAndGetItsText());
    driver.findElement(By.id("txtFirstName")).clear();
    driver.findElement(By.id("txtFirstName")).sendKeys("Alpha");
    driver.findElement(By.id("btnPayment")).click();
    assertEquals("Please fill the Last Name", closeAlertAndGetItsText());
    driver.findElement(By.id("txtLastName")).clear();
    driver.findElement(By.id("txtLastName")).sendKeys("Beta");
    driver.findElement(By.id("btnPayment")).click();
    assertEquals("Please fill the Email", closeAlertAndGetItsText());
    driver.findElement(By.id("txtEmail")).clear();
    driver.findElement(By.id("txtEmail")).sendKeys("sdfd@gmg.");
    driver.findElement(By.id("btnPayment")).click();
    assertEquals("Please enter valid Email Id.", closeAlertAndGetItsText());
    driver.findElement(By.id("txtEmail")).clear();
    driver.findElement(By.id("txtEmail")).sendKeys("sdfd@gmg.cc");
    driver.findElement(By.id("btnPayment")).click();
    assertEquals("Please fill the Mobile No.", closeAlertAndGetItsText());
    driver.findElement(By.id("txtPhone")).clear();
    driver.findElement(By.id("txtPhone")).sendKeys("123123");
    driver.findElement(By.id("btnPayment")).click();
    assertEquals("Please enter valid Contact no.", closeAlertAndGetItsText());
    driver.findElement(By.id("txtPhone")).clear();
    driver.findElement(By.id("txtPhone")).sendKeys("9231231231");
    driver.findElement(By.id("btnPayment")).click();
    assertEquals("Please select your gender", closeAlertAndGetItsText());
    driver.findElement(By.id("m")).click();
    driver.findElement(By.id("btnPayment")).click();
    assertEquals("Please select atleast one hobby", closeAlertAndGetItsText());
    driver.findElement(By.id("read")).click();
    driver.findElement(By.id("btnPayment")).click();
    assertEquals("Please select city", closeAlertAndGetItsText());
    new Select(driver.findElement(By.name("city"))).selectByVisibleText("Pune");
    driver.findElement(By.id("btnPayment")).click();
    assertEquals("Please select state", closeAlertAndGetItsText());
    new Select(driver.findElement(By.name("state"))).selectByVisibleText("Karnataka");
    driver.findElement(By.id("btnPayment")).click();
    assertEquals("Please fill the Card holder name", closeAlertAndGetItsText());
    driver.findElement(By.id("txtCardholderName")).clear();
    driver.findElement(By.id("txtCardholderName")).sendKeys("Alpha");
    driver.findElement(By.id("btnPayment")).click();
    assertEquals("Please fill the Debit card Number", closeAlertAndGetItsText());
    driver.findElement(By.id("txtDebit")).clear();
    driver.findElement(By.id("txtDebit")).sendKeys("234234234");
    driver.findElement(By.id("btnPayment")).click();
    assertEquals("Please fill the CVV", closeAlertAndGetItsText());
    driver.findElement(By.id("txtCvv")).clear();
    driver.findElement(By.id("txtCvv")).sendKeys("213");
    driver.findElement(By.id("btnPayment")).click();
    assertEquals("Please fill expiration month", closeAlertAndGetItsText());
    driver.findElement(By.id("txtMonth")).clear();
    driver.findElement(By.id("txtMonth")).sendKeys("12");
    driver.findElement(By.id("btnPayment")).click();
    assertEquals("Please fill the expiration year", closeAlertAndGetItsText());
    driver.findElement(By.id("txtYear")).clear();
    driver.findElement(By.id("txtYear")).sendKeys("2222");
    driver.findElement(By.id("btnPayment")).click();
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
